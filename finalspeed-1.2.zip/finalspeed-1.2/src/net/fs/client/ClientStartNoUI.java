// Copyright (c) 2015 D1SM.net

package net.fs.client;

public class ClientStartNoUI {

	public static void main(String[] args) {
		new ClientNoUI();
	}

}
