// Copyright (c) 2015 D1SM.net

package net.fs.cap;

public class SendRecord {
	
	int sendCount;

}
