// Copyright (c) 2015 D1SM.net

package net.fs.rudp;

public class Constant {

	
	public static int code_success=1;
	
	public static int code_failed=0;
	
	public static int code_no_port=41;
	
	public static int code_password_error=42;
	
	static int protocal_portmap=5755682;
	
	public static int protocal_socks5proxy=544643;

}
